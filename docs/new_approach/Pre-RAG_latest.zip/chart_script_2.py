import plotly.graph_objects as go

# Define API layers with endpoints matching instructions but within 15-char limit
api_layers = {
    'User Interface': {
        'y_level': 5,
        'color': '#1FB8CD',
        'endpoints': [
            'POST /eval/req',
            'POST /eval/upload', 
            'GET /eval/status',
            'GET /eval/results'
        ]
    },
    'Core Evaluation': {
        'y_level': 4,
        'color': '#DB4545',
        'endpoints': [
            'POST /eval/embed',
            'POST /eval/chunk',
            'POST /eval/vector',
            'POST /eval/llm',
            'POST /eval/retrv',
            'POST /eval/prompt'
        ]
    },
    'Optimization': {
        'y_level': 3,
        'color': '#2E8B57',
        'endpoints': [
            'POST /opt/multi',
            'POST /opt/iter',
            'GET /opt/pareto'
        ]
    },
    'Metrics Analysis': {
        'y_level': 2,
        'color': '#5D878F',
        'endpoints': [
            'POST /met/rouge',
            'POST /met/ragas',
            'POST /met/perf',
            'POST /ana/cost'
        ]
    },
    'Configuration': {
        'y_level': 1,
        'color': '#D2BA4C',
        'endpoints': [
            'GET /cfg/rec',
            'POST /cfg/valid',
            'POST /cfg/deploy'
        ]
    }
}

# Create figure
fig = go.Figure()

# Add API boxes for each layer with better spacing
for layer_name, layer_info in api_layers.items():
    y_pos = layer_info['y_level']
    endpoints = layer_info['endpoints']
    color = layer_info['color']
    
    # Calculate x positions with better spacing
    num_endpoints = len(endpoints)
    if num_endpoints <= 3:
        # For 3 or fewer endpoints, center them
        start_x = 0.5 - (num_endpoints - 1) * 0.15
        x_positions = [start_x + i * 0.3 for i in range(num_endpoints)]
    else:
        # For more endpoints, spread across more of the width
        x_positions = [0.15 + (i * 0.7) / (num_endpoints - 1) for i in range(num_endpoints)]
    
    for i, endpoint in enumerate(endpoints):
        x_pos = x_positions[i]
        
        # Add larger, more readable boxes
        fig.add_trace(go.Scatter(
            x=[x_pos],
            y=[y_pos],
            mode='markers+text',
            marker=dict(
                size=120,  # Even larger boxes
                color=color,
                symbol='square',
                line=dict(width=2, color='white')
            ),
            text=endpoint,
            textposition='middle center',
            textfont=dict(size=11, color='white', family='Arial Black'),
            name=layer_name,
            showlegend=(i == 0),
            hovertemplate=f'<b>{endpoint}</b><br>Layer: {layer_name}<extra></extra>'
        ))

# Add cleaner connection arrows with no overlaps
arrow_paths = [
    # User Interface to Core Evaluation (center)
    {'start': (0.5, 4.8), 'end': (0.5, 4.2), 'color': '#13343B'},
    # Core Evaluation to Optimization (left side)
    {'start': (0.3, 3.8), 'end': (0.3, 3.2), 'color': '#13343B'},
    # Core Evaluation to Metrics (right side)
    {'start': (0.7, 3.8), 'end': (0.7, 2.2), 'color': '#13343B'},
    # Optimization to Configuration (left)
    {'start': (0.3, 2.8), 'end': (0.3, 1.2), 'color': '#13343B'},
    # Metrics to Configuration (right)
    {'start': (0.7, 1.8), 'end': (0.7, 1.2), 'color': '#13343B'}
]

for arrow in arrow_paths:
    start, end = arrow['start'], arrow['end']
    
    # Add line
    fig.add_trace(go.Scatter(
        x=[start[0], end[0]],
        y=[start[1], end[1]],
        mode='lines',
        line=dict(width=3, color=arrow['color']),
        showlegend=False,
        hoverinfo='skip'
    ))
    
    # Add arrow head
    fig.add_annotation(
        x=end[0],
        y=end[1],
        ax=start[0],
        ay=start[1],
        xref='x',
        yref='y',
        axref='x',
        ayref='y',
        arrowhead=2,
        arrowsize=1.5,
        arrowwidth=3,
        arrowcolor=arrow['color'],
        showarrow=True
    )

# Add layer labels with better positioning
layer_names = ['User Interface', 'Core Evaluation', 'Optimization', 'Metrics Analysis', 'Configuration']
layer_colors = ['#1FB8CD', '#DB4545', '#2E8B57', '#5D878F', '#D2BA4C']

for i, (name, color) in enumerate(zip(layer_names, layer_colors)):
    fig.add_trace(go.Scatter(
        x=[0.05],
        y=[5-i],
        mode='text',
        text=name,
        textposition='middle left',
        textfont=dict(size=12, color=color, family='Arial Black'),
        showlegend=False,
        hoverinfo='skip'
    ))

# Update layout with proper margins and spacing
fig.update_layout(
    title='RAG Eval Service APIs',
    xaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0, 1]
    ),
    yaxis=dict(
        showgrid=False,
        showticklabels=False,
        zeroline=False,
        range=[0.5, 5.5]
    ),
    legend=dict(
        orientation='h',
        yanchor='bottom',
        y=1.02,
        xanchor='center',
        x=0.5
    ),
    plot_bgcolor='white',
    paper_bgcolor='white'
)

fig.update_traces(cliponaxis=False)

# Save the chart
fig.write_image("rag_api_design.png")
fig.write_image("rag_api_design.svg", format="svg")

fig.show()